// Checks the JSON data before it goes live. Run: node scripts/validate.mjs
import fs from "node:fs";
import path from "node:path";
const dir = "data", problems = [];
const read = (rel) => {
  try { return JSON.parse(fs.readFileSync(path.join(dir, rel), "utf8")); }
  catch (e) { problems.push(`${rel}: ${e.message}`); return null; }
};
const manifest = read("manifest.json");
if (!manifest) finish();
// files on disk that the manifest does not list
for (const [sub, list] of [["flows", manifest.flows || []], ["shared", manifest.shared || []]]) {
  for (const f of fs.readdirSync(path.join(dir, sub)).filter((x) => x.endsWith(".json")))
    if (!list.includes(`${sub}/${f}`)) problems.push(`${sub}/${f} exists but is not listed in manifest.json`);
}
const shared = {};
for (const rel of manifest.shared || []) {
  const o = read(rel); if (!o) continue;
  for (const [k, v] of Object.entries(o)) {
    if (k in shared) problems.push(`${rel}: shared box "${k}" is defined twice`);
    shared[k] = v;
  }
}
// shared boxes that use other shared boxes must exist too
const checkUse = (ns, where) => (ns || []).forEach((n) => {
  if (n.use && !shared[n.use]) problems.push(`${where}: shared box "${n.use}" does not exist`);
  checkUse(n.children, where);
});
for (const [k, v] of Object.entries(shared)) checkUse(v.children, `shared "${k}"`);
const expand = (ns, pre) => (ns || []).map((n) => {
  let r = { ...n };
  if (n.use && shared[n.use]) { r = { ...structuredClone(shared[n.use]), ...n }; delete r.use; r.id = n.id || `${pre}-${n.use}`; }
  if (r.children) r.children = expand(r.children, r.id);
  return r;
});
const flowIds = [];
for (const rel of manifest.flows || []) {
  const f = read(rel); if (!f) continue;
  for (const key of ["id", "title", "nodes"]) if (!f[key]) problems.push(`${rel}: missing "${key}"`);
  if (!f.nodes) continue;
  if (flowIds.includes(f.id)) problems.push(`${rel}: flow id "${f.id}" is used twice`);
  flowIds.push(f.id);
  checkUse(f.nodes, rel);
  const nodes = expand(f.nodes, f.id), ids = new Map(), views = (f.views || []).map((v) => v[0]);
  const walk = (ns, fn) => ns.forEach((n) => { fn(n); if (n.children) { if (!n.children.length) problems.push(`${rel}: "${n.title}" has an empty children list`); walk(n.children, fn); } });
  walk(nodes, (n) => { if (!n.title) problems.push(`${rel}: a box with id "${n.id}" has no title`); ids.set(n.id, (ids.get(n.id) || 0) + 1); });
  ids.forEach((c, id) => { if (c > 1) problems.push(`${rel}: id "${id}" is used ${c} times`); });
  walk(nodes, (n) => {
    if (n.goto && !ids.has(n.goto)) problems.push(`${rel}: goto "${n.goto}" points to no box`);
    if (n.scenario && views.length && !views.includes(n.scenario)) problems.push(`${rel}: scenario "${n.scenario}" is not in views`);
  });
}
finish();
function finish() {
  if (problems.length) { console.error(problems.map((p) => "✗ " + p).join("\n")); process.exit(1); }
  console.log(`OK: ${(manifest.flows || []).length} flows, ${Object.keys(shared).length} shared boxes`);
}
