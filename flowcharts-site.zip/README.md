# Flowcharts

Interactive flow diagrams for payment flows. Static site: no build step, no libraries.

## Structure
- `index.html` – the page. Reads everything in `data/` with `fetch()`.
- `data/manifest.json` – lists every flow file and shared file, in menu order.
- `data/flows/<id>.json` – one flow per file (id, group, title, views, extraFilters, nodes).
- `data/shared/*.json` – reusable boxes (key → box). Use them in a flow with `{ "use": "key" }`.
- `scripts/validate.mjs` – checks the data (also runs on every push via GitHub Actions).

## Add a flow
1. Create `data/flows/my-flow.json` (copy a snippet from `flows-template.json`).
2. Add `"flows/my-flow.json"` to `data/manifest.json`. The menu follows this order and groups by each flow's `group`.

## Add or change a shared box
Edit the right file in `data/shared/`. Keys must be unique across all shared files. A change applies everywhere the box is used.

## Run locally
The page cannot read files when opened directly from disk. Use a server:

    python -m http.server 8000     # then open http://localhost:8000

## Check the data
    node scripts/validate.mjs

## GitHub Pages
Settings → Pages → Deploy from branch → `main` / root. Changes show after a minute or two (caching).
